

#import <UIKit/UIKit.h>

@interface CalendarViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *dataLabel;

@property (strong, nonatomic) id dataObject;

@end
